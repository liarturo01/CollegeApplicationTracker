package finalproject.collegeapplicationtracker;

import javafx.application.Application;

/**
 * Launches the application
 */
public class Launcher {
    public static void main(String[] args) {
        Application.launch(CollegeTracker.class, args);
    }
}
